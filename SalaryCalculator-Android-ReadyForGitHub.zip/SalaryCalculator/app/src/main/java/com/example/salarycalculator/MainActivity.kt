package com.example.salarycalculator

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import java.io.OutputStream
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var rate: EditText
    private lateinit var hours: EditText
    private lateinit var days: EditText
    private lateinit var output: TextView
    private var pdfLines: List<String> = emptyList()
    private val pdfRequest = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = ScrollView(this)
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 52, 48, 48); setBackgroundColor(Color.rgb(248, 250, 252)) }
        root.addView(panel)
        fun heading(text: String, size: Float) = TextView(this).apply { this.text = text; textSize = size; setTextColor(Color.rgb(20, 35, 55)); setPadding(0, 0, 0, 24) }
        panel.addView(heading("Salary Calculator", 28f))
        fun field(label: String, default: String): EditText {
            panel.addView(heading(label, 16f))
            return EditText(this).also { it.setSingleLine(true); it.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL; it.setText(default); panel.addView(it) }
        }
        rate = field("Hourly Rate ($)", "25")
        hours = field("Hours per Day", "8")
        days = field("Working Days per Week", "5")
        val calculate = Button(this).apply { text = "Calculate" }
        panel.addView(calculate)
        output = heading("", 19f).apply { gravity = Gravity.START; setPadding(0, 24, 0, 24) }
        panel.addView(output)
        val pdf = Button(this).apply { text = "Save as PDF" }
        panel.addView(pdf)
        calculate.setOnClickListener { calculate() }
        pdf.setOnClickListener {
            if (calculate()) {
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"; putExtra(Intent.EXTRA_TITLE, "salary-calculation.pdf") }
                startActivityForResult(intent, pdfRequest)
            }
        }
        setContentView(root)
        calculate()
    }
    private fun calculate(): Boolean {
        val r = rate.text.toString().toDoubleOrNull()
        val h = hours.text.toString().toDoubleOrNull()
        val d = days.text.toString().toDoubleOrNull()
        if (r == null || h == null || d == null || !r.isFinite() || !h.isFinite() || !d.isFinite() || r < 0 || h < 0 || d < 0 || h > 24 || d > 7) {
            output.text = "Enter valid non-negative values (hours 0–24; days 0–7)."
            return false
        }
        val daily = r * h
        val weekly = daily * d
        fun money(n: Double) = String.format(Locale.US, "$%,.2f", n)
        pdfLines = listOf("Salary Calculator", "Hourly Rate: ${money(r)}", "Hours per Day: $h", "Working Days per Week: $d", "", "Daily Pay: ${money(daily)}", "Weekly Pay: ${money(weekly)}", "Biweekly Pay: ${money(weekly * 2)}", "Monthly Pay (average): ${money(weekly * 52 / 12)}", "Annual Pay: ${money(weekly * 52)}", "", "Gross pay only. No taxes or deductions.")
        output.text = pdfLines.drop(5).joinToString("\n")
        return true
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pdfRequest && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val document = PdfDocument()
                val page = document.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; textSize = 16f }
                pdfLines.forEachIndexed { index, line -> page.canvas.drawText(line, 45f, 65f + index * 34f, paint) }
                document.finishPage(page)
                contentResolver.openOutputStream(uri)?.use { document.writeTo(it) }
                document.close()
                Toast.makeText(this, "PDF saved", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) { Toast.makeText(this, "Could not save PDF", Toast.LENGTH_LONG).show() }
        }
    }
}
