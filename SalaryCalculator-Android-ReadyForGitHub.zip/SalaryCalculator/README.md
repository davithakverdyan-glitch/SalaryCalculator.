# Salary Calculator for Android

Offline Android application. English interface, gross salary calculations and PDF export.

Open this folder in Android Studio, allow Gradle sync, then choose Build > Build APK(s).
The APK will be in `app/build/outputs/apk/debug/`.

Calculation: daily = hourly rate × hours/day; weekly = daily × working days/week; biweekly = weekly × 2; monthly average = weekly × 52 / 12; annual = weekly × 52. No taxes, deductions, or overtime premiums.
